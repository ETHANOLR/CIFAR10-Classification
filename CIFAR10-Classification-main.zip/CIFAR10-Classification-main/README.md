ABOUT
-------------------------

This program classifies CIFAR10 dataset using four different machine learning methods: kNN, logistic, feedforward neural network, and convolutional neural network.
